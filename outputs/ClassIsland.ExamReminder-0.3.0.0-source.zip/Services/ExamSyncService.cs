using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using ClassIsland.ExamReminder.Models;
using Microsoft.Extensions.Hosting;

namespace ClassIsland.ExamReminder.Services;

public sealed record ExamCache(string Scope, DateTimeOffset CheckedAt, ExamBoardBootstrapResponse Snapshot);

public sealed class ExamSyncService : BackgroundService
{
    private readonly PluginSettingsStore _store;
    private readonly ExamBoardClient _client;
    private readonly ExamReminderProvider _provider;
    private readonly ExternalUriLauncher _launcher;
    private readonly ReminderSuppressionService _suppression;
    private volatile ExamBoardBootstrapResponse? _snapshot;
    private DateTimeOffset _validatedAt = DateTimeOffset.MinValue;
    private DateTimeOffset _lastFullSync = DateTimeOffset.MinValue;
    private sealed record ClockAnchor(DateTimeOffset ServerTime, long Timestamp);
    private volatile ClockAnchor? _clock;
    private long _generation;
    private long _syncRequestVersion;
    private long _nextSyncMs;
    private Task? _networkTask;
    private int _failures;
    private int _offlineChecks;
    private int _reopens;
    private DateTimeOffset _nextOpen = DateTimeOffset.MinValue;
    private string _precheckKey = "";
    private string _modeDescription = "";
    public bool UsingCache { get; private set; }
    public bool ViewerStatusKnown { get; private set; }
    public string SyncMode { get; private set; } = "尚未同步";
    public string RuntimeError { get; private set; } = "";
    public long SuccessfulChecks { get; private set; }
    public long FailedChecks { get; private set; }
    public long BrowserOpenAttempts { get; private set; }
    public double LastRequestMilliseconds { get; private set; }
    /// <summary>最近一次网络尝试时间；失败时也会推进，用于和最近成功同步区分。</summary>
    public DateTimeOffset? LastAttemptAt { get; private set; }
    /// <summary>当前考试快照在校正后的时间轴上完成校验的时刻。</summary>
    public DateTimeOffset? DataValidatedAt => _validatedAt == DateTimeOffset.MinValue ? null : _validatedAt;
    public ExamSession? CurrentSession { get; private set; }
    public ExamSession? NextSession { get; private set; }
    public IReadOnlyList<ExamBoardExam> Exams => _snapshot?.Exams ?? [];
    public string ModeDescription => _modeDescription;
    public DateTimeOffset? NextSyncAt => (_store.Settings.EnableAutoSync || !_store.Settings.IsPaired) && Interlocked.Read(ref _nextSyncMs) is > 0 and < long.MaxValue ? DateTimeOffset.FromUnixTimeMilliseconds(Interlocked.Read(ref _nextSyncMs)) : null;
    public DateTimeOffset Now => _clock is {} clock
        ? clock.ServerTime.Add(Stopwatch.GetElapsedTime(clock.Timestamp))
        : DateTimeOffset.UtcNow.AddMilliseconds(_store.Settings.ServerOffsetMilliseconds);

    public ExamSyncService(PluginSettingsStore store, ExamBoardClient client, ExamReminderProvider provider, ExternalUriLauncher launcher, ReminderSuppressionService suppression)
    {
        _store = store; _client = client; _provider = provider; _launcher = launcher; _suppression = suppression;
        try
        {
            var cache = store.Read<ExamCache>("Exams.cache.json");
            if (store.Settings.IsPaired && store.Settings.UseOfflineCache && cache is not null && cache.Scope == Scope(store.Settings) &&
                cache.CheckedAt <= DateTimeOffset.UtcNow && DateTimeOffset.UtcNow - cache.CheckedAt <= TimeSpan.FromHours(store.Settings.CacheMaxHours))
            {
                _snapshot = cache.Snapshot;
                _validatedAt = cache.CheckedAt;
                UsingCache = true;
            }
        }
        catch { RuntimeError = "考试缓存不可用，等待联网同步"; }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(1));
        try
        {
            do
            {
                if ((_store.Settings.EnableAutoSync || !_store.Settings.IsPaired || Interlocked.Read(ref _nextSyncMs) == 0) &&
                    (_networkTask is null || _networkTask.IsCompleted) && DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() >= Interlocked.Read(ref _nextSyncMs))
                    _networkTask = SynchronizeSafelyAsync(stoppingToken);
                try { EvaluateSchedule(); }
                catch (Exception ex) { RuntimeError = $"本地调度异常：{ex.Message}"; _suppression.SetActive(false); }
            } while (await timer.WaitForNextTickAsync(stoppingToken));
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
        finally
        {
            _suppression.SetActive(false);
            if (_networkTask is not null) await _networkTask;
        }
    }

    public void RequestImmediateSync(bool full = false)
    {
        Interlocked.Increment(ref _syncRequestVersion);
        if (full) _lastFullSync = DateTimeOffset.MinValue;
        Interlocked.Exchange(ref _nextSyncMs, 0);
    }

    public void Reschedule() => Schedule(_store.Settings.SyncSeconds);

    public void ResetConnection()
    {
        Interlocked.Increment(ref _generation);
        _snapshot = null;
        CurrentSession = NextSession = null;
        _suppression.SetActive(false);
        _failures = _offlineChecks = _reopens = 0;
        _nextOpen = DateTimeOffset.MinValue;
        _lastFullSync = DateTimeOffset.MinValue;
        _clock = null;
        ViewerStatusKnown = false;
        UsingCache = false;
        _store.Update(s => { s.SkippedSessionKey = ""; s.CompletedActions = s.CompletedActions.Where(x => x.Count(c => c == '|') != 2).ToList(); });
        RequestImmediateSync(true);
    }

    public void SkipCurrentSession()
    {
        if (CurrentSession is {} session) _store.Update(s => s.SkippedSessionKey = session.Key);
        EvaluateSchedule();
    }

    public bool TryShowCurrentOrNextExamReminder(out string error)
    {
        var exam = Exams.Where(x => x.EndAt > Now).OrderBy(x => x.StartAt).FirstOrDefault();
        if (exam is null) { error = "没有可用于测试的考试，请先同步考试数据"; return false; }
        _provider.ShowExamReminder(exam, exam.StartAt - Now);
        error = "";
        return true;
    }

    private async Task SynchronizeSafelyAsync(CancellationToken token)
    {
        var generation = Interlocked.Read(ref _generation);
        var requestVersion = Interlocked.Read(ref _syncRequestVersion);
        // An independent copy prevents pairing edits from changing an in-flight request.
        var current = _store.Settings;
        var settings = new PluginSettings { BaseUrl = current.BaseUrl, PluginInstanceId = current.PluginInstanceId, ClientSecret = current.ClientSecret,
            IsPaired = current.IsPaired, PendingPairToken = current.PendingPairToken, PairExpiresAt = current.PairExpiresAt };
        Interlocked.Exchange(ref _nextSyncMs, long.MaxValue);
        LastAttemptAt = DateTimeOffset.Now;
        try
        {
            if (string.IsNullOrWhiteSpace(settings.BaseUrl)) { Schedule(60); return; }
            if (!settings.IsPaired)
            {
                if (string.IsNullOrWhiteSpace(settings.PendingPairToken)) { Schedule(60); return; }
                if (settings.PairExpiresAt <= DateTimeOffset.Now)
                {
                    _store.Update(s => { s.PendingPairToken = ""; s.PairExpiresAt = null; s.LastStatus = "浏览器绑定已过期，请重新连接"; });
                    Schedule(60); return;
                }
                var pair = await _client.GetPairStatusAsync(settings, token);
                if (generation != Interlocked.Read(ref _generation)) return;
                if (!pair.IsSuccess || pair.Value?.Ok != true) { Failure(pair.Error ?? "无法查询配对状态", pair.RetryAfter); return; }
                if (!pair.Value.Paired) { Status("等待浏览器完成班级配对"); Schedule(5, false); return; }
                _store.Update(s => { s.IsPaired = true; s.BoundClassTag = pair.Value.ClassTag ?? ""; s.PendingPairToken = ""; s.PairExpiresAt = null; });
            }

            var full = _snapshot is null || DateTimeOffset.UtcNow - _lastFullSync >= TimeSpan.FromMinutes(_store.Settings.FullSyncMinutes);
            var started = Stopwatch.GetTimestamp();
            var result = await _client.GetBootstrapAsync(settings, full ? null : _snapshot?.Version, token);
            LastRequestMilliseconds = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
            if (generation != Interlocked.Read(ref _generation)) return;
            if (!result.IsSuccess || result.Value?.Ok != true)
            {
                if (result.StatusCode is 401 or 403 or 409)
                {
                    _snapshot = null;
                    _suppression.SetActive(false);
                    _store.Update(s => { s.IsPaired = false; s.PendingPairToken = ""; s.BoundClassTag = ""; s.BoundGradeId = s.BoundClassId = ""; s.NextExamName = ""; s.NextExamStartAt = null; });
                }
                Failure(result.Error ?? "考试看板拒绝同步", result.RetryAfter);
                return;
            }
            var data = result.Value;
            if (data.ApiVersion > 2) { Failure("考试看板 API 版本过新，请更新插件", TimeSpan.FromMinutes(10)); return; }
            if (data.ServerTime.Year < 2020 || data.ServerTime.Year > 2200 || (data.Changed && (data.Exams is null || data.Exams.Any(x =>
                string.IsNullOrWhiteSpace(x.Id) || string.IsNullOrWhiteSpace(x.Name) || x.StartAt.Year < 2020 || x.EndAt <= x.StartAt))))
            { Failure("考试数据或服务器时间无效，保留上次有效数据"); return; }
            if (!data.Changed && (_snapshot is null || string.IsNullOrEmpty(data.Version) || data.Version != _snapshot.Version))
            { _lastFullSync = DateTimeOffset.MinValue; Failure("轻量同步版本不一致，等待完整校验"); return; }

            if (!data.Changed)
            {
                // Preserve the complete schedule when the server returns only status.
                data.Exams = _snapshot!.Exams;
                data.Binding = _snapshot.Binding;
            }
            else
            {
                if (!data.Capabilities.Contains("session-history") && _snapshot is {} previous &&
                    data.Binding?.ClassTag is {} classTag && classTag == previous.Binding?.ClassTag)
                {
                    var today = TimeZoneInfo.ConvertTime(data.ServerTime, ExamSchedule.TimeZone(_store.Settings)).Date;
                    var completed = previous.Exams.Where(x => x.EndAt <= data.ServerTime &&
                        TimeZoneInfo.ConvertTime(x.StartAt, ExamSchedule.TimeZone(_store.Settings)).Date == today &&
                        !data.Exams.Any(y => y.Id == x.Id));
                    data.Exams = data.Exams.Concat(completed).ToList();
                }
                _lastFullSync = DateTimeOffset.UtcNow;
            }

            _clock = new ClockAnchor(data.ServerTime.Add(Stopwatch.GetElapsedTime(started) / 2), Stopwatch.GetTimestamp());
            _validatedAt = DateTimeOffset.UtcNow;
            _snapshot = data;
            SuccessfulChecks++;
            _failures = 0;
            UsingCache = false;
            ViewerStatusKnown = true;
            SyncMode = string.IsNullOrEmpty(data.Version) ? "兼容同步（完整数据）" : "轻量同步";
            RuntimeError = "";
            var nextExam = data.Exams.Where(x => x.EndAt > Now).OrderBy(x => x.StartAt).FirstOrDefault();
            _store.Update(s =>
            {
                if (data.Binding is {} binding && ((binding.ClassId.Length > 0 && s.BoundClassId != binding.ClassId) || s.BoundClassTag != binding.ClassTag)) s.SkippedSessionKey = "";
                s.BoundClassTag = data.Binding?.ClassTag ?? s.BoundClassTag;
                s.BoundGradeId = data.Binding?.GradeId ?? s.BoundGradeId;
                s.BoundClassId = data.Binding?.ClassId ?? s.BoundClassId;
                s.LastSyncAt = DateTimeOffset.Now;
                s.ViewerOnline = data.ViewerOnline;
                if (data.ViewerOnline) s.LastViewerConfirmedAt = DateTimeOffset.Now;
                s.ServerOffsetMilliseconds = (long)(Now - DateTimeOffset.UtcNow).TotalMilliseconds;
                s.NextExamName = nextExam?.Name ?? ""; s.NextExamStartAt = nextExam?.StartAt;
                s.LastStatus = "已同步考试看板";
            });
            if (_store.Settings.CompletedActions.Any(x => x.Count(c => c == '|') == 2))
            {
                var actionScope = Scope(_store.Settings) + "|";
                _store.Update(s => s.CompletedActions = s.CompletedActions.Select(x => x.Count(c => c == '|') == 2 ? actionScope + x : x).Distinct().TakeLast(2000).ToList());
            }
            try { _store.Write("Exams.cache.json", new ExamCache(Scope(_store.Settings), _validatedAt, data)); }
            catch (Exception ex) { RuntimeError = $"考试缓存未保存：{ex.Message}"; }
            EvaluateProtection(data);
            Schedule(_store.Settings.SyncSeconds);
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { }
        catch (Exception ex) { if (generation == Interlocked.Read(ref _generation)) Failure($"同步失败：{ex.Message}"); }
        finally
        {
            if (generation != Interlocked.Read(ref _generation)) RequestImmediateSync(true);
            else if (requestVersion != Interlocked.Read(ref _syncRequestVersion)) Interlocked.Exchange(ref _nextSyncMs, 0);
        }
    }

    private void Failure(string error, TimeSpan? retryAfter = null)
    {
        FailedChecks++;
        ViewerStatusKnown = false;
        UsingCache = _snapshot is not null;
        _offlineChecks = 0;
        Status(error);
        _failures = Math.Min(_failures + 1, 10);
        var delay = Math.Max(_store.Settings.SyncSeconds, Math.Min(_store.Settings.MaxRetryMinutes * 60, _store.Settings.SyncSeconds * Math.Pow(2, _failures - 1)));
        if (retryAfter is {} retry && retry.TotalSeconds > delay) delay = Math.Min(retry.TotalSeconds, 86400);
        Schedule(delay);
    }

    private void Schedule(double seconds, bool stagger = true)
    {
        // Only delay, never shorten the configured minimum interval.
        var jitter = stagger && _store.Settings.StaggerRequests ? Random.Shared.NextDouble() * Math.Min(seconds * 0.1, 10) : 0;
        Interlocked.Exchange(ref _nextSyncMs, DateTimeOffset.UtcNow.AddSeconds(seconds + jitter).ToUnixTimeMilliseconds());
    }

    private void Status(string text) => _store.Update(s => s.LastStatus = text);

    private void EvaluateSchedule()
    {
        var s = _store.Settings;
        var snapshot = _snapshot;
        var valid = s.IsPaired && snapshot is not null && DateTimeOffset.UtcNow - _validatedAt <= TimeSpan.FromHours(s.CacheMaxHours) &&
            (!UsingCache || s.UseOfflineCache);
        if (!valid)
        {
            CurrentSession = NextSession = null;
            _modeDescription = snapshot is null ? "等待考试数据" : "缓存已停用或过期，等待联网";
            _suppression.SetActive(false);
            return;
        }
        var now = Now;
        var sessions = ExamSchedule.Sessions(snapshot!.Exams, s);
        CurrentSession = sessions.FirstOrDefault(x => x.Start <= now && x.End > now);
        NextSession = sessions.FirstOrDefault(x => x.End > now);
        var active = s.EnableExamMode && CurrentSession is {} session && session.Key != s.SkippedSessionKey;
        _suppression.SetActive(active);
        _modeDescription = !s.EnableExamMode ? "自动考试模式已关闭" : CurrentSession is null ? "尚未进入考试时段" :
            active ? "考试模式进行中" : "本时段已暂不启用";

        var scope = Scope(s);
        foreach (var exam in snapshot.Exams)
        {
            foreach (var minutes in s.ReminderMinutes!.Concat(s.EnableStartReminder ? new[] { 0 } : Array.Empty<int>()))
            {
                var key = scope + "|" + ExamSchedule.ActionKey(exam, minutes == 0 ? "start" : $"reminder-{minutes}");
                if (ExamSchedule.IsDue(exam, minutes, now, s.ReminderGraceSeconds) && !_store.HasCompletedAction(key))
                {
                    _provider.ShowExamReminder(exam, TimeSpan.FromMinutes(minutes));
                    _store.MarkCompletedAction(key);
                }
            }
            if (!s.AutoOpenBoard || now >= exam.StartAt || exam.StartAt - now > TimeSpan.FromMinutes(s.BrowserLeadMinutes)) continue;
            var openKey = scope + "|" + ExamSchedule.ActionKey(exam, "open");
            if (!_store.HasCompletedAction(openKey))
            {
                if (ViewerStatusKnown && snapshot.ViewerOnline) _store.MarkCompletedAction(openKey);
                else if (now >= _nextOpen && TryOpenBoard("考前自动打开看板")) _store.MarkCompletedAction(openKey);
            }
            if (s.EnableAutoSync && s.PreStartCheckMinutes > 0 && exam.StartAt - now <= TimeSpan.FromMinutes(s.PreStartCheckMinutes))
            {
                var checkKey = scope + "|" + ExamSchedule.ActionKey(exam, "precheck");
                if (_precheckKey != checkKey)
                {
                    _precheckKey = checkKey;
                    if (DateTimeOffset.UtcNow - _validatedAt > TimeSpan.FromSeconds(10)) RequestImmediateSync();
                }
            }
        }
    }

    private void EvaluateProtection(ExamBoardBootstrapResponse data)
    {
        var s = _store.Settings;
        if (data.ViewerOnline) { _offlineChecks = _reopens = 0; return; }
        var near = s.PreStartCheckMinutes > 0 && data.Exams.Any(x => x.StartAt > Now && x.StartAt - Now <= TimeSpan.FromMinutes(s.PreStartCheckMinutes));
        var active = data.Exams.Any(x => x.StartAt <= Now && x.EndAt > Now);
        if (!s.AutoOpenBoard || (!near && !(active && s.EnableExamGuard))) { _offlineChecks = 0; return; }
        _offlineChecks++;
        if ((near || _offlineChecks >= s.OfflineChecksBeforeReopen) && Now >= _nextOpen) TryOpenBoard("看板离线，尝试恢复");
    }

    private bool TryOpenBoard(string reason)
    {
        BrowserOpenAttempts++;
        var s = _store.Settings;
        var delay = Math.Max(s.BrowserCooldownSeconds, Math.Min(s.MaxBrowserCooldownMinutes * 60, s.BrowserCooldownSeconds * Math.Pow(2, Math.Min(_reopens, 8))));
        _nextOpen = Now.AddSeconds(delay);
        _reopens++;
        _offlineChecks = 0;
        if (_launcher.TryOpen(ExamBoardUrls.Board(s.BaseUrl, s.PluginInstanceId), out var error)) { Status(reason + "，已发起打开"); return true; }
        Status("无法打开考试看板：" + error);
        return false;
    }

    private static string Scope(PluginSettings s) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{s.BaseUrl}|{s.PluginInstanceId}|{s.ClientSecret}|{s.BoundGradeId}|{(s.BoundClassId.Length > 0 ? s.BoundClassId : s.BoundClassTag)}")));
}

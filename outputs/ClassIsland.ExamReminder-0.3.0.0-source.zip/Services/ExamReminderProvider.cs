using Avalonia.Threading;
using ClassIsland.Core.Abstractions.Services.NotificationProviders;
using ClassIsland.Core.Attributes;
using ClassIsland.Core.Models.Notification;
using ClassIsland.ExamReminder.Models;
using NotificationSettings = ClassIsland.Shared.Models.Notification.NotificationSettings;

namespace ClassIsland.ExamReminder.Services;

[NotificationProviderInfo(ProviderId, "考试提醒", "\uE7C0", "从考试看板同步考试，并在开考前显示提醒")]
public sealed class ExamReminderProvider(PluginSettingsStore store) : NotificationProviderBase
{
    public const string ProviderId = "8A997522-E450-4FE8-924F-04A4829B8B5C";

    public void ShowExamReminder(ExamBoardExam exam, TimeSpan remaining)
    {
        var settings = store.Settings;
        var minutes = Math.Max(0, (int)Math.Ceiling(remaining.TotalMinutes));
        var text = ExamSchedule.Format(minutes == 0 ? settings.StartTemplate : settings.ReminderTemplate, exam, minutes, settings);
        Dispatcher.UIThread.Post(() =>
        {
            var mask = NotificationContent.CreateTwoIconsMask(text);
            mask.SpeechContent = text;
            mask.IsSpeechEnabled = settings.EnableSpeech;
            mask.Duration = TimeSpan.FromSeconds(settings.ReminderDurationSeconds);
            var overlay = NotificationContent.CreateSimpleTextContent(
                $"开考时间：{TimeZoneInfo.ConvertTime(exam.StartAt, ExamSchedule.TimeZone(settings)):HH:mm} · {settings.BoundClassTag}");
            overlay.IsSpeechEnabled = false;
            ShowNotification(new NotificationRequest
            {
                MaskContent = mask,
                OverlayContent = overlay,
                RequestNotificationSettings = new NotificationSettings
                {
                    IsSettingsEnabled = true,
                    IsNotificationEnabled = true,
                    IsSpeechEnabled = settings.EnableSpeech
                }
            });
        });
    }
}

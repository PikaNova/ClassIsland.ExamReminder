using ClassIsland.ExamReminder.Models;

namespace ClassIsland.ExamReminder.Services;

public sealed record ExamSession(string Key, DateTimeOffset Start, DateTimeOffset End);

public static class ExamSchedule
{
    public static TimeZoneInfo TimeZone(PluginSettings settings) => TimeZoneInfo.FindSystemTimeZoneById(settings.SchoolTimeZone);

    public static IReadOnlyList<ExamSession> Sessions(IEnumerable<ExamBoardExam> exams, PluginSettings settings)
    {
        var zone = TimeZone(settings);
        var ranges = exams.Where(x => x.EndAt > x.StartAt).GroupBy(x =>
        {
            var local = TimeZoneInfo.ConvertTime(x.StartAt, zone);
            return $"{local:yyyy-MM-dd}|{(local.Hour < settings.SessionBoundaryHour ? "AM" : "PM")}";
        }).Select(group => new ExamSession(group.Key,
            group.Min(x => x.StartAt).AddMinutes(-settings.ExamModeLeadMinutes),
            group.Max(x => x.EndAt).AddMinutes(settings.ExamModeTailMinutes))).OrderBy(x => x.Start).ToList();
        var merged = new List<ExamSession>();
        foreach (var range in ranges)
        {
            if (merged.Count > 0 && range.Start <= merged[^1].End)
            {
                var previous = merged[^1];
                merged[^1] = previous with { Key = previous.Key + "+" + range.Key, End = range.End > previous.End ? range.End : previous.End };
            }
            else merged.Add(range);
        }
        return merged;
    }

    public static string ActionKey(ExamBoardExam exam, string action) => $"{exam.Id}|{exam.StartAt.UtcTicks}|{action}";

    /// <summary>返回与当前学校日期相交的考试，包含已结束的场次，按开始时间排序。</summary>
    public static IReadOnlyList<ExamBoardExam> Today(IEnumerable<ExamBoardExam> exams, PluginSettings settings, DateTimeOffset now)
    {
        var zone = TimeZone(settings);
        var today = TimeZoneInfo.ConvertTime(now, zone).Date;
        return exams.Where(x =>
                TimeZoneInfo.ConvertTime(x.StartAt, zone).Date == today ||
                TimeZoneInfo.ConvertTime(x.EndAt, zone).Date == today)
            .OrderBy(x => x.StartAt).ToList();
    }

    public static string Phase(ExamBoardExam exam, DateTimeOffset now) =>
        exam.EndAt <= now ? "已结束" : exam.StartAt <= now ? "进行中" : "待开始";

    public static bool IsDue(ExamBoardExam exam, int minutes, DateTimeOffset now, int graceSeconds)
    {
        var due = exam.StartAt.AddMinutes(-minutes);
        return now >= due && now <= due.AddSeconds(graceSeconds) &&
            (minutes == 0 ? now < exam.EndAt : now < exam.StartAt);
    }

    public static string Format(string template, ExamBoardExam exam, int minutes, PluginSettings settings) =>
        template.Replace("{考试}", exam.Name).Replace("{分钟}", minutes.ToString())
            .Replace("{班级}", settings.BoundClassTag)
            .Replace("{时间}", TimeZoneInfo.ConvertTime(exam.StartAt, TimeZone(settings)).ToString("HH:mm"));
}

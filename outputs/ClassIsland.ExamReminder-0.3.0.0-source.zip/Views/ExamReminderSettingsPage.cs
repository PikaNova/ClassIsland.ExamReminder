using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using ClassIsland.Core.Abstractions.Controls;
using ClassIsland.Core.Abstractions.Services.SpeechService;
using ClassIsland.Core.Attributes;
using ClassIsland.Core.Enums.SettingsWindow;
using ClassIsland.ExamReminder.Models;
using ClassIsland.ExamReminder.Services;
using ClassIsland.Shared;
using Markdown.Avalonia;

namespace ClassIsland.ExamReminder.Views;

[SettingsPageInfo("classisland.exam-reminder.settings", "考试提醒", "\uE7C0", "\uE7C0", SettingsPageCategory.External)]
public sealed class ExamReminderSettingsPage : SettingsPageBase
{
    private readonly PluginSettingsStore _store;
    private readonly ExamBoardClient _client;
    private readonly ExamSyncService _sync;
    private readonly ExternalUriLauncher _launcher;
    private readonly ReminderSuppressionService _suppression;
    private readonly AnnouncementService _announcements;
    private readonly List<Action> _loaders = [];
    private readonly TextBox _url = new() { Watermark = "http://192.168.1.20:3000 或 https://exam.example.com" };
    private readonly TextBlock _connection = Text("", 14);
    private readonly TextBlock _nextTitle = Text("暂无考试", 26);
    private readonly TextBlock _nextDetail = Text("");
    private readonly TextBlock _mode = Text("");
    private readonly TextBlock _syncStatus = Text("");
    private readonly TextBlock _feedback = Text("");
    private readonly TextBlock _announcementStatus = Text("");
    private readonly TextBlock _announcementCount = Text("", 13);
    private readonly TextBlock _suppressionStatus = Text("");
    private readonly TextBlock _sourceSummary = Text("", 13);
    private readonly TextBlock _diagnostics = Text("", 12);
    private readonly TextBlock _todayHint = Text("", 13);
    private readonly TextBlock _speechStatus = Text("", 13);
    private readonly StackPanel _todayList = new() { Spacing = 8 };
    private readonly StackPanel _announcementList = new() { Spacing = 12 };
    private readonly StackPanel _sources = new() { Spacing = 8 };
    private readonly CheckBox _unreadOnly = new() { Content = "只看未读", VerticalAlignment = VerticalAlignment.Center };
    private readonly Button _markAllRead = new() { Content = "全部标为已读" };
    private readonly Button _refreshAnnouncements = new() { Content = "刷新公告" };
    private readonly Button _connect = new() { Content = "连接并在浏览器绑定", Classes = { "accent" } };
    private readonly Button _skip = new() { Content = "本时段暂不启用" };
    private readonly TabItem _announcementTab = new() { Header = "作者公告" };
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly HashSet<string> _expandedAnnouncements = [];
    private bool _refreshing;
    private bool _attached;
    private string _announcementFingerprint = "";
    private string _todayFingerprint = "";
    private string _stickyFeedback = "";
    private DateTimeOffset _feedbackExpiresAt = DateTimeOffset.MaxValue;

    public ExamReminderSettingsPage(PluginSettingsStore store, ExamBoardClient client, ExamSyncService sync,
        ExternalUriLauncher launcher, ReminderSuppressionService suppression, AnnouncementService announcements)
    {
        _store = store; _client = client; _sync = sync; _launcher = launcher; _suppression = suppression; _announcements = announcements;
        _connect.Click += async (_, _) => await ConnectAsync();
        _skip.Click += (_, _) => _sync.SkipCurrentSession();
        _markAllRead.Click += (_, _) =>
        {
            _announcements.MarkAllRead();
            _expandedAnnouncements.Clear();
            RenderAnnouncements(true);
        };
        _refreshAnnouncements.Click += (_, _) => { _expandedAnnouncements.Clear(); _announcements.Refresh(); RefreshStatus(); };
        _unreadOnly.PropertyChanged += (_, e) =>
        {
            if (e.Property != ToggleButton.IsCheckedProperty) return;
            _expandedAnnouncements.Clear();
            RenderAnnouncements(true);
        };
        var header = new Grid { ColumnDefinitions = new("*,Auto"), Margin = new(0, 0, 0, 4) };
        header.Children.Add(new StackPanel { Spacing = 4, Children = { Text("考试提醒", 28, true), Text("连接考试看板，让提醒跟随考试安排。", 13) } });
        var version = Text("v" + ExamBoardClient.ClientVersion, 12);
        Grid.SetColumn(version, 1); header.Children.Add(version);

        var overview = new StackPanel
        {
            Spacing = 16,
            Children =
            {
                Card("下一场考试", new StackPanel { Spacing = 8, Children = { _nextTitle, _nextDetail } }),
                Card("今日安排", new StackPanel { Spacing = 10, Children = { _todayHint, _todayList } }),
                Card("自动考试模式", new StackPanel { Spacing = 10, Children = { _mode, _skip } }),
                Card("设备与同步", new StackPanel
                {
                    Spacing = 12, Children =
                    {
                        _syncStatus,
                        Buttons(ActionButton("立即同步", () => _sync.RequestImmediateSync()),
                            ActionButton("完整校验", () => _sync.RequestImmediateSync(true)),
                            ActionButton("打开看板", OpenBoard),
                            ActionButton("测试考试提醒", () =>
                            {
                                if (_sync.TryShowCurrentOrNextExamReminder(out var error)) SetFeedback("已显示测试提醒");
                                else SetFeedback(error, true);
                            }))
                    }
                }),
                ConnectionCard()
            }
        };
        var options = new StackPanel { Spacing = 16 };
        options.Children.Add(Card("考试提醒与语音", new StackPanel
        {
            Spacing = 12, Children =
            {
                Switch("考试语音", "使用 ClassIsland 当前语音引擎；仍遵守宿主的语音开关。", s => s.EnableSpeech, (s,v) => s.EnableSpeech = v),
                _speechStatus,
                Buttons(ActionButton("测试语音引擎", TestSpeechEngine)),
                Text("测试会直接调用 ClassIsland 当前语音引擎，不依赖考试数据。", 12),
                TextSetting("考前提醒节点", "填写提前分钟数，用逗号分隔；留空关闭考前提醒。最多 20 个，范围 1–1440。",
                    s => string.Join(", ", s.ReminderMinutes!), (s,v) => s.ReminderMinutes = ParseMinutes(v)),
                Switch("开考时提醒", "考试开始时显示并按语音开关播报。", s => s.EnableStartReminder, (s,v) => s.EnableStartReminder = v),
                TextSetting("考前文案", "可用占位符：{考试}、{分钟}、{班级}、{时间}。", s => s.ReminderTemplate, (s,v) => s.ReminderTemplate = v),
                TextSetting("开考文案", "显示文字与语音使用同一文案。", s => s.StartTemplate, (s,v) => s.StartTemplate = v),
                Number("提醒显示时长", "秒，3–120。", s => s.ReminderDurationSeconds, (s,v) => s.ReminderDurationSeconds = v, 3, 120),
                Number("允许延迟触发", "秒；超过此时间的提醒不补播，避免启动后集中响起。", s => s.ReminderGraceSeconds, (s,v) => s.ReminderGraceSeconds = v, 0, 600)
            }
        }));
        options.Children.Add(Card("自动考试模式", new StackPanel
        {
            Spacing = 12, Children =
            {
                Switch("启用自动考试模式", "同一上午或下午连续生效，场间也屏蔽选中的提醒。", s => s.EnableExamMode, (s,v) => s.EnableExamMode = v),
                Number("提前进入", "分钟，首场考试前开始。", s => s.ExamModeLeadMinutes, (s,v) => s.ExamModeLeadMinutes = v, 0, 240, s => s.EnableExamMode),
                Number("延后退出", "分钟，最后一场结束后继续保持。", s => s.ExamModeTailMinutes, (s,v) => s.ExamModeTailMinutes = v, 0, 240, s => s.EnableExamMode),
                Number("上午／下午分界", "学校当地时间的小时；默认 13:00，跨中午考试全程覆盖。", s => s.SessionBoundaryHour, (s,v) => s.SessionBoundaryHour = v, 1, 23, s => s.EnableExamMode),
                TextSetting("学校时区", "默认 Asia/Shanghai，也支持系统可识别的其他时区。", s => s.SchoolTimeZone, (s,v) =>
                {
                    TimeZoneInfo.FindSystemTimeZoneById(v.Trim()); s.SchoolTimeZone = v.Trim();
                }),
                Text("勾选考试期间要屏蔽的提醒提供方。上下课整组控制，包含准备上课和课间休息。未勾选的来源正常保留。", 13),
                _suppressionStatus,
                _sourceSummary,
                _sources,
                Buttons(ActionButton("默认来源", () => SetSuppressed(PluginSettings.DefaultSuppressedProviderIds)),
                    ActionButton("全选", () => SetSuppressed(_suppression.Sources().Select(x => x.Id))),
                    ActionButton("清空", () => SetSuppressed([])),
                    ActionButton("刷新可选提醒来源", BuildSources))
            }
        }));
        options.Children.Add(Card("看板自动打开与守护", new StackPanel
        {
            Spacing = 12, Children =
            {
                Switch("自动打开考试看板", "由本地考试时间触发；看板在线时不会重复打开。", s => s.AutoOpenBoard, (s,v) => s.AutoOpenBoard = v),
                Number("提前打开", "分钟，1–240；建议至少 20 分钟。", s => s.BrowserLeadMinutes, (s,v) => s.BrowserLeadMinutes = v, 1, 240, s => s.AutoOpenBoard),
                Number("考前复查窗口", "分钟；0 表示关闭额外复查。", s => s.PreStartCheckMinutes, (s,v) => s.PreStartCheckMinutes = v, 0, 30, s => s.AutoOpenBoard),
                Switch("考试期间守护看板", "网络未知不会直接当作离线；检查频率跟随同步设置。", s => s.EnableExamGuard, (s,v) => s.EnableExamGuard = v, s => s.AutoOpenBoard),
                Number("连续离线确认次数", "成功检查确认离线达到此次数后重开。", s => s.OfflineChecksBeforeReopen, (s,v) => s.OfflineChecksBeforeReopen = v, 1, 10, s => s.AutoOpenBoard && s.EnableExamGuard),
                Number("重开最短间隔", "秒，连续失败会逐步延长间隔。", s => s.BrowserCooldownSeconds, (s,v) => s.BrowserCooldownSeconds = v, 30, 3600, s => s.AutoOpenBoard),
                Number("重开退避上限", "分钟；不低于上面的最短间隔。", s => s.MaxBrowserCooldownMinutes, (s,v) => s.MaxBrowserCooldownMinutes = v, 1, 120, s => s.AutoOpenBoard)
            }
        }));
        var network = new StackPanel
        {
            Spacing = 16, Children =
            {
                Card("同步与服务器负载", new StackPanel
                {
                    Spacing = 12, Children =
                    {
                        Text("默认每分钟检查版本，只有数据变化才拉取完整考试。缩短间隔会增加服务器压力。", 13),
                        Switch("自动同步", "关闭后仅启动、配对或手动操作时同步，临时考试变更不会自动获取。", s => s.EnableAutoSync, (s,v) => { s.EnableAutoSync = v; _sync.Reschedule(); }),
                        Number("检查间隔", "秒，30–3600；默认 60 秒。保存后立即按新间隔重新计时。", s => s.SyncSeconds, (s,v) => { s.SyncSeconds = v; _sync.Reschedule(); }, 30, 3600),
                        Number("完整校验周期", "分钟；实际不会快于检查间隔。", s => s.FullSyncMinutes, (s,v) => s.FullSyncMinutes = v, 1, 1440),
                        Number("请求超时", "秒；网络等待不会阻塞考试提醒。", s => s.RequestTimeoutSeconds, (s,v) => s.RequestTimeoutSeconds = v, 3, 60),
                        Number("失败退避上限", "分钟；服务器 Retry-After 可要求等待更久。", s => s.MaxRetryMinutes, (s,v) => s.MaxRetryMinutes = v, 1, 120),
                        Switch("错开设备请求", "在检查间隔后增加少量随机延迟，减少集中访问。", s => s.StaggerRequests, (s,v) => s.StaggerRequests = v),
                        Switch("断网继续使用考试缓存", "使用已成功校验的考试安排，考试模式仍会按时结束。", s => s.UseOfflineCache, (s,v) => s.UseOfflineCache = v),
                        Number("缓存有效期", "小时，超过有效期后停止根据旧数据自动操作。", s => s.CacheMaxHours, (s,v) => s.CacheMaxHours = v, 1, 168, s => s.UseOfflineCache)
                    }
                }),
                Card("公告获取", new StackPanel
                {
                    Spacing = 12, Children =
                    {
                        Switch("自动检查作者公告", "仅在设置页展示，不弹窗、不播报。", s => s.EnableAnnouncements, (s,v) => { s.EnableAnnouncements = v; _announcements.Refresh(); }),
                        Number("公告检查周期", "分钟，5–1440；失败会降低检查频率。", s => s.AnnouncementRefreshMinutes, (s,v) => { s.AnnouncementRefreshMinutes = v; _announcements.Refresh(); }, 5, 1440),
                        TextSetting("自定义公告地址", "留空使用当前看板的作者公告接口；未连接时使用作者公开接口。仅请求公开内容，不发送配对凭据。",
                            s => s.AnnouncementUrl, (s,v) =>
                            {
                                if (!string.IsNullOrWhiteSpace(v) && (!Uri.TryCreate(v, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https") || uri.UserInfo.Length > 0))
                                    throw new ArgumentException("请输入 HTTP 或 HTTPS 公告地址");
                                s.AnnouncementUrl = v.Trim(); _announcements.Refresh();
                            })
                    }
                }),
                Card("关于与诊断", new StackPanel
                {
                    Spacing = 10, Children =
                    {
                        Text("适配 ClassIsland 2.1.0.1 · 提醒屏蔽使用运行时兼容适配，不改动课表或宿主提醒设置。", 13),
                        new Expander { Header = "同步诊断", Content = _diagnostics },
                        Buttons(ActionButton("复制诊断信息", () => _ = CopyDiagnosticsAsync()),
                            ActionButton("打开项目主页", () => _launcher.TryOpen(new Uri("https://github.com/PikaNova/ClassIsland.ExamReminder"), out _)))
                    }
                })
            }
        };
        _announcementTab.Content = Scroll(new StackPanel
        {
            Spacing = 16, Children =
            {
                Card("作者公告", new StackPanel
                {
                    Spacing = 10, Children =
                    {
                        Text("作者发布的更新与使用说明。公告只在本页展示，考试期间也不会打断提醒。", 13),
                        _announcementStatus,
                        _announcementCount,
                        Buttons(_refreshAnnouncements, _markAllRead, _unreadOnly)
                    }
                }),
                _announcementList
            }
        });
        var tabs = new TabControl
        {
            ItemsSource = new[]
            {
                new TabItem { Header = "概览", Content = Scroll(overview) },
                new TabItem { Header = "提醒与考试模式", Content = Scroll(options) },
                _announcementTab,
                new TabItem { Header = "连接与高级", Content = Scroll(network) }
            }
        };
        tabs.SelectionChanged += (_, _) => { if (tabs.SelectedItem == _announcementTab) RenderAnnouncements(true); };
        Content = new Grid
        {
            Margin = new Thickness(24, 12, 24, 20),
            RowDefinitions = new("Auto,Auto,*"),
            Children = { header }
        };
        var grid = (Grid)Content;
        _feedback.Margin = new(0, 4, 0, 10); Grid.SetRow(_feedback, 1); grid.Children.Add(_feedback);
        Grid.SetRow(tabs, 2); grid.Children.Add(tabs);
        _timer.Tick += (_, _) => RefreshStatus();
        AttachedToVisualTree += (_, _) =>
        {
            if (_attached) return;
            _attached = true;
            _store.Changed += OnChanged; _announcements.Changed += OnChanged;
            BuildSources(); LoadSettings(); RefreshStatus(); _timer.Start();
        };
        DetachedFromVisualTree += (_, _) =>
        {
            _attached = false; _timer.Stop();
            _store.Changed -= OnChanged; _announcements.Changed -= OnChanged;
        };
        BuildSources(); LoadSettings(); RefreshStatus();
    }

    private Control ConnectionCard() => Card("考试看板连接", new StackPanel
    {
        Spacing = 12, Children =
        {
            _connection, _url,
            Text("支持内网 HTTP、域名及端口，接口和考试大屏路径自动补全。HTTP 连接未加密。", 12),
            Buttons(_connect, ActionButton("断开本机连接", () =>
            {
                _store.Update(s => { s.IsPaired = false; s.PendingPairToken = ""; s.PairExpiresAt = null; s.BoundClassTag = ""; s.LastStatus = "已断开，请重新连接"; });
                _sync.ResetConnection();
            }))
        }
    });

    private async Task ConnectAsync()
    {
        if (!ExamBoardUrls.TryNormalizeBaseUrl(_url.Text ?? "", out var url, out var error)) { SetFeedback(error, true); return; }
        _connect.IsEnabled = false;
        SetFeedback("正在创建配对，请稍候…");
        try
        {
            var token = PluginSettings.CreateSecret();
            _store.Update(s => { s.BaseUrl = url; s.IsPaired = false; s.BoundClassTag = ""; s.BoundGradeId = s.BoundClassId = ""; s.PendingPairToken = token; s.PairExpiresAt = DateTimeOffset.Now.AddMinutes(5); s.LastStatus = "正在创建浏览器配对"; s.ServerOffsetMilliseconds = 0; });
            _sync.ResetConnection();
            var s = _store.Settings;
            var result = await _client.StartPairingAsync(url, s.PluginInstanceId, s.ClientSecret, token);
            if (!result.IsSuccess || result.Value is null)
            {
                _store.Update(v => { v.PendingPairToken = ""; v.PairExpiresAt = null; v.LastStatus = result.Error ?? "配对失败"; });
                SetFeedback(result.Error ?? "配对失败", true); return;
            }
            if (_launcher.TryOpen(result.Value, out var launchError))
            {
                SetFeedback("请在浏览器中确认班级绑定。");
                _sync.RequestImmediateSync();
            }
            else SetFeedback("浏览器启动失败：" + launchError, true);
            _announcements.Refresh();
        }
        catch (Exception ex) { SetFeedback("连接失败：" + ex.Message, true); }
        finally { _connect.IsEnabled = true; }
    }

    private void OpenBoard()
    {
        if (!ExamBoardUrls.TryNormalizeBaseUrl(_store.Settings.BaseUrl, out var url, out var error)) { SetFeedback(error, true); return; }
        if (!_launcher.TryOpen(ExamBoardUrls.Board(url, _store.Settings.PluginInstanceId), out error)) SetFeedback(error, true);
    }

    private void OnChanged(object? sender, EventArgs e) => Dispatcher.UIThread.Post(() =>
    {
        if (!_attached) return;
        LoadSettings(); RefreshStatus();
    });

    private void LoadSettings()
    {
        _refreshing = true;
        try
        {
            if (!_url.IsFocused) _url.Text = _store.Settings.BaseUrl;
            foreach (var loader in _loaders) loader();
        }
        finally { _refreshing = false; }
    }

    private void RefreshStatus()
    {
        var s = _store.Settings;
        _connection.Text = s.IsPaired ? $"已连接 · {s.BoundClassTag}" : !string.IsNullOrEmpty(s.PendingPairToken)
            ? $"等待浏览器绑定 · 有效至 {s.PairExpiresAt:HH:mm:ss}" : "尚未连接考试看板";
        var now = _sync.Now;
        var exam = _sync.Exams.Where(x => x.EndAt > now).OrderBy(x => x.StartAt).FirstOrDefault();
        _nextTitle.Text = exam?.Name ?? "暂无考试";
        _nextDetail.Text = exam is null ? "同步成功后将在此显示当前或下一场考试。" :
            $"{Local(exam.StartAt):MM-dd HH:mm}–{Local(exam.EndAt):HH:mm} · {(exam.StartAt <= now ? "进行中" : $"距开考 {Math.Ceiling((exam.StartAt - now).TotalMinutes)} 分钟")}";
        var session = _sync.NextSession;
        _mode.Text = _sync.ModeDescription + (session is null ? "" : $"\n{Local(session.Start):MM-dd HH:mm}–{Local(session.End):HH:mm}") +
            $"\n已选择屏蔽 {s.SuppressedProviders.Count} 个提醒提供方";
        var skippedCurrent = _sync.CurrentSession is {} active && s.SkippedSessionKey == active.Key;
        _skip.IsEnabled = s.EnableExamMode && _sync.CurrentSession is not null && !skippedCurrent;
        _skip.Content = skippedCurrent ? "本时段已跳过" : "本时段暂不启用";
        RenderToday(now);
        _suppressionStatus.Text = _suppression.Status;
        _speechStatus.Text = SpeechStatusText(s.EnableSpeech);
        _diagnostics.Text = BuildRuntimeDiagnostics();
        var viewer = !_sync.ViewerStatusKnown ? "未知" : s.ViewerOnline ? "在线" : "离线";
        var lastSuccess = s.LastSyncAt is {} success ? success.ToString("MM-dd HH:mm:ss") : "—";
        var lastAttempt = _sync.LastAttemptAt is {} attempt ? attempt.ToString("MM-dd HH:mm:ss") : "—";
        var nextCheck = _sync.NextSyncAt is {} nextAt
            ? $"{nextAt.ToLocalTime():HH:mm:ss}（{Math.Max(0, (int)Math.Ceiling((nextAt - DateTimeOffset.Now).TotalSeconds))} 秒后）"
            : "已关闭";
        var cache = _sync.UsingCache && _sync.DataValidatedAt is {} validated
            ? $" · 缓存于 {validated.ToLocalTime():MM-dd HH:mm}" : "";
        _syncStatus.Text = $"班级：{(s.IsPaired ? s.BoundClassTag : "未绑定")}    看板：{viewer}\n" +
            $"最近成功：{lastSuccess}    上次尝试：{lastAttempt}\n" +
            $"下次检查：{nextCheck}\n{_sync.SyncMode}{cache}\n{s.LastStatus}";
        var error = _store.SaveError ?? (_sync.RuntimeError.Length > 0 ? _sync.RuntimeError : "");
        if (error.Length > 0) { _feedback.Text = error; _stickyFeedback = error; }
        else
        {
            if (_stickyFeedback.Length > 0) { _feedback.Text = ""; _stickyFeedback = ""; }
            if (_feedbackExpiresAt != DateTimeOffset.MaxValue && DateTimeOffset.Now >= _feedbackExpiresAt)
            {
                _feedback.Text = "";
                _feedbackExpiresAt = DateTimeOffset.MaxValue;
            }
        }
        _announcementTab.Header = _announcements.UnreadCount > 0 ? $"作者公告 · {_announcements.UnreadCount}" : "作者公告";
        _announcementStatus.Text = AnnouncementStatusText();
        _announcementCount.Text = $"共 {_announcements.Items.Count} 条 · 未读 {_announcements.UnreadCount} 条";
        _markAllRead.IsEnabled = _announcements.UnreadCount > 0 && !_announcements.IsChecking;
        _refreshAnnouncements.IsEnabled = !_announcements.IsChecking;
        _refreshAnnouncements.Content = _announcements.IsChecking ? "检查中…" : "刷新公告";
        _unreadOnly.IsEnabled = _announcements.Items.Count > 0;
        RenderAnnouncements();
    }

    private string AnnouncementStatusText()
    {
        if (!_store.Settings.EnableAnnouncements) return "作者公告自动检查已关闭";
        var text = _announcements.IsChecking ? "正在检查作者公告…" : _announcements.Status;
        try { _ = _announcements.Source(); }
        catch (ArgumentException ex) { return ex.Message; }
        if (_announcements.LastCheckedAt is {} at) text += $"\n最近成功：{at:MM-dd HH:mm}";
        if (!_announcements.IsChecking && _announcements.LastAttemptAt is {} attempt &&
            (_announcements.LastCheckedAt is null || attempt > _announcements.LastCheckedAt.Value.AddSeconds(1)))
            text += $" · 上次尝试：{attempt:HH:mm}";
        return text;
    }

    private static string SpeechProviderName(ISpeechService speech) => speech.GetType().Name switch
    {
        "SystemSpeechService" => "系统 TTS",
        "EdgeTtsService" => "Edge TTS",
        "GptSoVitsService" => "GPT-SoVITS",
        _ => speech.GetType().Name
    };

    private string SpeechStatusText(bool pluginSpeechEnabled)
    {
        var speech = IAppHost.TryGetService<ISpeechService>();
        if (speech is null) return "语音引擎：宿主未提供语音服务";
        var volume = ISpeechService.GlobalSettings?.SpeechVolume;
        var volumeText = volume is null ? "宿主音量未知" : $"宿主音量 {volume:P0}";
        var line = $"语音引擎：{SpeechProviderName(speech)} · {volumeText} · 本插件考试语音{(pluginSpeechEnabled ? "已开启" : "已关闭")}";
        return volume is { } value && value <= 0.001 ? line + "\n宿主语音音量为 0，提醒不会发声。" : line;
    }

    private void TestSpeechEngine()
    {
        var speech = IAppHost.TryGetService<ISpeechService>();
        if (speech is null) { SetFeedback("宿主未提供语音服务，请重启 ClassIsland 后再试。", true); return; }
        var volume = ISpeechService.GlobalSettings?.SpeechVolume;
        if (volume is { } value && value <= 0.001)
        {
            SetFeedback("宿主语音音量为 0%，请在 ClassIsland 设置中调高音量后再测试。", true);
            return;
        }
        var provider = SpeechProviderName(speech);
        try
        {
            speech.ClearSpeechQueue();
            speech.EnqueueSpeechQueue("这是考试提醒的语音引擎测试。如果你听到这句话，说明语音引擎工作正常。");
            SetFeedback(provider == "Edge TTS"
                ? "已请求 Edge TTS 朗读。Edge TTS 需要联网；如果无声，请切换到系统 TTS。"
                : $"已请求{provider}朗读，宿主音量 {(volume ?? 1):P0}。如果无声，请检查 Windows 输出设备。", provider == "Edge TTS");
        }
        catch (Exception ex) { SetFeedback("语音引擎调用失败：" + ex.GetBaseException().Message, true); }
    }

    private string BuildRuntimeDiagnostics()
    {
        var detail = _announcements.LastErrorDetail;
        if (detail.Length > 500) detail = detail[..500] + "…";
        return $"本次运行：成功 {_sync.SuccessfulChecks} 次，失败 {_sync.FailedChecks} 次\n" +
            $"最近请求耗时：{_sync.LastRequestMilliseconds:F0} ms\n" +
            $"自动打开看板：{_sync.BrowserOpenAttempts} 次\n" +
            $"服务端校时偏差：{_store.Settings.ServerOffsetMilliseconds} ms\n" +
            $"最近尝试：{Time(_sync.LastAttemptAt)}\n" +
            $"数据校验：{Time(_sync.DataValidatedAt)}\n" +
            $"{_suppression.Status}\n" +
            $"作者公告：{_announcements.Status}" +
            (detail.Length > 0 ? $"\n公告错误：{detail}" : "");
    }

    private string BuildClipboardDiagnostics()
    {
        var s = _store.Settings;
        var lines = new[]
        {
            $"考试提醒 {ExamBoardClient.ClientVersion}",
            $"服务器：{s.BaseUrl}",
            $"班级：{s.BoundClassTag}（{(s.IsPaired ? "已连接" : "未连接")}）",
            $"同步：{_sync.SyncMode} · 成功 {_sync.SuccessfulChecks} / 失败 {_sync.FailedChecks}",
            $"最近成功：{Time(s.LastSyncAt)} · 上次尝试：{Time(_sync.LastAttemptAt)} · 数据校验：{Time(_sync.DataValidatedAt)}",
            $"看板：{(_sync.ViewerStatusKnown ? (s.ViewerOnline ? "在线" : "离线") : "未知")} · 使用缓存：{(_sync.UsingCache ? "是" : "否")}",
            $"状态：{s.LastStatus}",
            $"提醒屏蔽：{_suppression.Status} · 已选 {s.SuppressedProviders.Count} 项",
            $"作者公告：{_announcements.Status} · 最近成功 {Time(_announcements.LastCheckedAt)}",
            _announcements.LastErrorDetail.Length > 0 ? $"公告错误：{_announcements.LastErrorDetail}" : "",
            "--- 运行诊断 ---",
            BuildRuntimeDiagnostics()
        };
        return string.Join("\n", lines.Where(x => x.Length > 0));
    }

    private async Task CopyDiagnosticsAsync()
    {
        var clipboard = TopLevel.GetTopLevel(this)?.Clipboard;
        if (clipboard is null) { SetFeedback("无法访问剪贴板", true); return; }
        try
        {
            await clipboard.SetTextAsync(BuildClipboardDiagnostics());
            SetFeedback("诊断信息已复制");
        }
        catch (Exception ex) { SetFeedback("复制失败：" + ex.Message, true); }
    }

    private void RenderToday(DateTimeOffset now)
    {
        IReadOnlyList<ExamBoardExam> today;
        try { today = ExamSchedule.Today(_sync.Exams, _store.Settings, now); }
        catch (Exception ex)
        {
            _todayHint.Text = "无法计算今日安排：" + ex.Message;
            _todayList.Children.Clear();
            _todayFingerprint = "";
            return;
        }
        var fingerprint = (_sync.Exams.Count > 0 ? "1" : "0") + "|" + string.Join(";", today.Select(x =>
            $"{x.Id}|{x.StartAt.UtcTicks}|{x.EndAt.UtcTicks}|{ExamSchedule.Phase(x, now)}"));
        if (fingerprint == _todayFingerprint) return;
        _todayFingerprint = fingerprint;
        _todayList.Children.Clear();
        if (_sync.Exams.Count == 0) { _todayHint.Text = "同步成功后将在此显示今天的考试安排。"; return; }
        if (today.Count == 0) { _todayHint.Text = "今天没有考试安排。"; return; }
        _todayHint.Text = $"今天共 {today.Count} 场考试";
        foreach (var exam in today.Take(6))
        {
            var phase = ExamSchedule.Phase(exam, now);
            var row = new Grid { ColumnDefinitions = new("Auto,*,Auto"), ColumnSpacing = 12 };
            var time = Text($"{Local(exam.StartAt):HH:mm}–{Local(exam.EndAt):HH:mm}", 12);
            var name = Text(exam.Name, 14, phase == "进行中");
            var state = Text(phase, 12);
            Grid.SetColumn(name, 1); Grid.SetColumn(state, 2);
            row.Children.Add(time); row.Children.Add(name); row.Children.Add(state);
            if (phase == "已结束") row.Opacity = 0.55;
            _todayList.Children.Add(row);
        }
        if (today.Count > 6) _todayList.Children.Add(Text($"另有 {today.Count - 6} 场，请查看看板。", 12));
    }

    private static string Time(DateTimeOffset? value) => value?.ToLocalTime().ToString("MM-dd HH:mm:ss") ?? "—";

    private DateTimeOffset Local(DateTimeOffset value)
    {
        try { return TimeZoneInfo.ConvertTime(value, ExamSchedule.TimeZone(_store.Settings)); }
        catch { return value.ToLocalTime(); }
    }

    private void BuildSources()
    {
        _sources.Children.Clear();
        var sources = _suppression.Sources();
        foreach (var source in sources)
        {
            var check = new CheckBox
            {
                Content = new TextBlock { Text = source.Name, TextWrapping = TextWrapping.Wrap },
                IsChecked = _store.Settings.SuppressedProviders.Contains(source.Id, StringComparer.OrdinalIgnoreCase),
                IsEnabled = _suppression.Supported
            };
            check.Click += (_, _) =>
            {
                Save(() => _store.Update(s => s.SuppressedProviders = check.IsChecked == true
                    ? s.SuppressedProviders.Append(source.Id).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
                    : s.SuppressedProviders.Where(x => !x.Equals(source.Id, StringComparison.OrdinalIgnoreCase)).ToList()));
                UpdateSourceSummary(sources);
            };
            _sources.Children.Add(check);
        }
        if (sources.Count == 0) _sources.Children.Add(Text("未发现可选的提醒来源。", 13));
        UpdateSourceSummary(sources);
    }

    private void UpdateSourceSummary(IReadOnlyList<ReminderSource>? sources = null)
    {
        sources ??= _suppression.Sources();
        var selected = sources.Count(x => _store.Settings.SuppressedProviders.Contains(x.Id, StringComparer.OrdinalIgnoreCase));
        _sourceSummary.Text = _suppression.Supported
            ? $"已选择 {selected} / {sources.Count} 个来源；未勾选的来源保持正常提醒。"
            : $"当前宿主不支持提醒屏蔽；{_suppression.Status}";
    }

    private void SetSuppressed(IEnumerable<string> ids)
    {
        if (!_suppression.Supported) { SetFeedback("当前宿主不支持提醒屏蔽", true); return; }
        var next = ids.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        Save(() => _store.Update(s => s.SuppressedProviders = next));
        BuildSources();
    }

    private void RenderAnnouncements(bool force = false)
    {
        if (force) _expandedAnnouncements.Clear();
        var all = _announcements.Items;
        _expandedAnnouncements.IntersectWith(all.Select(x => x.ReadKey));
        var unreadOnly = _unreadOnly.IsChecked == true;
        var items = unreadOnly
            ? all.Where(x => !_announcements.IsRead(x) || _expandedAnnouncements.Contains(x.ReadKey)).ToList()
            : all;
        string source;
        try { source = _announcements.Source().AbsoluteUri; }
        catch (ArgumentException) { return; }
        var fingerprint = AnnouncementFingerprint(source, all, unreadOnly);
        if (!force && fingerprint == _announcementFingerprint) return;
        _announcementFingerprint = fingerprint;
        _announcementList.Children.Clear();
        if (all.Count == 0)
        {
            _announcementList.Children.Add(Card("暂无作者公告", Text("成功获取后将在此显示；网络失败时保留上次缓存。", 13)));
            return;
        }
        if (items.Count == 0)
        {
            _announcementList.Children.Add(Card("没有未读公告", Text("已读公告仍会保留；取消“只看未读”即可查看。", 13)));
            return;
        }
        foreach (var item in items)
        {
            var key = item.ReadKey;
            var expander = new Expander
            {
                Header = $"{(item.Pinned ? "置顶 · " : "")}{(!_announcements.IsRead(item) ? "未读 · " : "")}{item.Title}",
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Stretch
            };
            expander.Expanding += (_, _) =>
            {
                // Keep a read article visible until the list is refreshed or the filter changes.
                _expandedAnnouncements.Add(key);
                if (expander.Content is null)
                {
                    var body = new StackPanel { Spacing = 12 };
                    body.Children.Add(Text(DateTimeOffset.FromUnixTimeMilliseconds(item.UpdatedAt).ToLocalTime().ToString("yyyy-MM-dd HH:mm"), 12));
                    body.Children.Add(new MarkdownScrollViewer
                    {
                        Markdown = item.Content,
                        AssetPathRoot = _announcements.Source().GetLeftPart(UriPartial.Authority),
                        MaxHeight = 640
                    });
                    if (Uri.TryCreate(item.Url, UriKind.Absolute, out var link) && link.Scheme is "http" or "https")
                        body.Children.Add(ActionButton(item.ButtonLabel ?? "打开文档", () => _launcher.TryOpen(link, out _)));
                    expander.Content = body;
                }
                _announcements.MarkRead(item);
                expander.Header = $"{(item.Pinned ? "置顶 · " : "")}{item.Title}";
                // Preserve the expanded article instead of rebuilding it when marking read.
                _announcementFingerprint = AnnouncementFingerprint(source, _announcements.Items, _unreadOnly.IsChecked == true);
            };
            _announcementList.Children.Add(Card("", expander));
        }
    }

    private string AnnouncementFingerprint(string source, IReadOnlyList<AuthorAnnouncement> items, bool unreadOnly) =>
        string.Join(";", items.Select(x => $"{x.ReadKey}|{_announcements.IsRead(x)}")) +
        $"|{source}|{items.Count}|{unreadOnly}|{string.Join(",", _expandedAnnouncements.OrderBy(x => x))}";

    private Control Switch(string title, string help, Func<PluginSettings, bool> get, Action<PluginSettings, bool> set, Func<PluginSettings, bool>? enabled = null)
    {
        var toggle = new ToggleSwitch { VerticalAlignment = VerticalAlignment.Center, OnContent = "开启", OffContent = "关闭" };
        toggle.PropertyChanged += (_, e) =>
        {
            if (!_refreshing && e.Property == ToggleButton.IsCheckedProperty) Save(() => _store.Update(s => set(s, toggle.IsChecked == true)));
        };
        _loaders.Add(() => { toggle.IsChecked = get(_store.Settings); toggle.IsEnabled = enabled?.Invoke(_store.Settings) ?? true; });
        return SettingRow(title, help, toggle);
    }

    private Control Number(string title, string help, Func<PluginSettings, int> get, Action<PluginSettings, int> set, int min, int max, Func<PluginSettings, bool>? enabled = null)
    {
        var number = new NumericUpDown { Minimum = min, Maximum = max, Increment = 1, FormatString = "0", Width = 116, HorizontalAlignment = HorizontalAlignment.Right };
        number.ValueChanged += (_, _) =>
        {
            if (!_refreshing && number.Value is {} value) Save(() => _store.Update(s => set(s, (int)value)));
        };
        _loaders.Add(() =>
        {
            if (!number.IsKeyboardFocusWithin) number.Value = get(_store.Settings);
            number.IsEnabled = enabled?.Invoke(_store.Settings) ?? true;
        });
        return SettingRow(title, help, number);
    }

    private Control TextSetting(string title, string help, Func<PluginSettings, string> get, Action<PluginSettings, string> set)
    {
        var box = new TextBox { MaxLength = 2000, HorizontalAlignment = HorizontalAlignment.Stretch };
        box.LostFocus += (_, _) =>
        {
            if (!_refreshing && box.Text != get(_store.Settings)) Save(() => _store.Update(s => set(s, box.Text ?? "")));
        };
        _loaders.Add(() => { if (!box.IsFocused) box.Text = get(_store.Settings); });
        return new StackPanel { Spacing = 6, Children = { Text(title, 14, true), Text(help, 12), box } };
    }

    private void Save(Action action)
    {
        try
        {
            action();
            if (_store.SaveError is {} saveError) SetFeedback(saveError, true);
            else SetFeedback("设置已保存");
        }
        catch (Exception ex) { SetFeedback("设置未应用：" + ex.Message, true); }
    }

    private void SetFeedback(string text, bool sticky = false)
    {
        _feedback.Text = text;
        _stickyFeedback = "";
        _feedbackExpiresAt = sticky ? DateTimeOffset.MaxValue : DateTimeOffset.Now.AddSeconds(6);
    }

    private static List<int> ParseMinutes(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return [];
        var pieces = value.Split(new[] { ',', '，', ';', '；', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        var result = new List<int>();
        foreach (var piece in pieces)
        {
            if (!int.TryParse(piece, out var minute) || minute < 1 || minute > 1440) throw new ArgumentException("提醒分钟数需在 1–1440 之间");
            result.Add(minute);
        }
        if (result.Distinct().Count() > 20) throw new ArgumentException("最多设置 20 个提醒节点");
        return result.Distinct().OrderDescending().ToList();
    }

    private static Control SettingRow(string title, string help, Control editor)
    {
        var panel = new StackPanel { Spacing = 4, HorizontalAlignment = HorizontalAlignment.Stretch };
        panel.Children.Add(Text(title, 14, true)); panel.Children.Add(Text(help, 12));
        var row = new Grid { ColumnDefinitions = new("*,Auto"), RowDefinitions = new("Auto,Auto"), ColumnSpacing = 20 };
        row.Children.Add(panel); Grid.SetColumn(editor, 1); row.Children.Add(editor);
        var narrow = false;
        row.SizeChanged += (_, e) =>
        {
            var next = e.NewSize.Width < 420;
            if (next == narrow) return;
            narrow = next;
            row.ColumnDefinitions = new(narrow ? "*" : "*,Auto");
            Grid.SetColumn(editor, narrow ? 0 : 1); Grid.SetRow(editor, narrow ? 1 : 0);
            editor.HorizontalAlignment = narrow ? HorizontalAlignment.Left : HorizontalAlignment.Right;
            editor.Margin = narrow ? new Thickness(0, 8, 0, 0) : new Thickness(0);
        };
        return row;
    }

    private static Border Card(string title, Control content)
    {
        var panel = new StackPanel { Spacing = 14 };
        if (title.Length > 0) panel.Children.Add(Text(title, 17, true));
        panel.Children.Add(content);
        return new Border
        {
            CornerRadius = new CornerRadius(12), Padding = new Thickness(20),
            BorderThickness = new Thickness(1),
            BorderBrush = new SolidColorBrush(Color.FromArgb(36, 128, 128, 128)),
            Background = new SolidColorBrush(Color.FromArgb(10, 128, 128, 128)),
            Child = panel
        };
    }
    private static TextBlock Text(string text, double size = 14, bool bold = false) => new()
    {
        Text = text, FontSize = size, FontWeight = bold ? FontWeight.SemiBold : FontWeight.Normal,
        TextWrapping = TextWrapping.Wrap, Opacity = size <= 13 ? 0.72 : 1
    };
    private static ScrollViewer Scroll(Control content) => new()
    {
        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
        Content = new Border { Margin = new Thickness(0, 16, 0, 24), Child = content }
    };
    private static Button ActionButton(string text, Action action)
    {
        var button = new Button { Content = text, Margin = new Thickness(0, 0, 8, 8) };
        button.Click += (_, _) => action(); return button;
    }
    private static WrapPanel Buttons(params Control[] controls)
    {
        var panel = new WrapPanel { Orientation = Orientation.Horizontal };
        foreach (var control in controls) panel.Children.Add(control);
        return panel;
    }
}
